<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Artikel</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="navbar">
        <a href="index.php">Beranda</a>
        <a href="articles.php">Artikel</a>
        <a href="profile.php">Profil</a>
    </div>
    <div class="content">
        <h1>List Artikel</h1>
        <ul>
            <li><a href="history_game_pertama.php">Sejarah Game Pertama</a></li> <!-- Tautan ke halaman "history_game_pertama.php" -->
        </ul>
    </div>
</body>
</html>
