<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sejarah Game Pertama</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="navbar">
        <a href="index.php">Beranda</a>
        <a href="articles.php">Artikel</a>
        <a href="profile.php">Profil</a>
    </div>
    <div class="content">
        <h1>Sejarah Game Pertama</h1>
        <p>Sejarah video game mencakup periode waktu antara penemuan game elektronik pertama hingga saat ini, mencakup banyak penemuan dan perkembangan. Video game mencapai popularitas arus utama pada tahun 1970 - an dan 1980 - an, ketika video game arcade , konsol game , dan game komputer rumahan diperkenalkan ke masyarakat umum. Sejak itu, video game telah menjadi bentuk hiburan populer dan bagian dari budaya modern di sebagian besar dunia. Oleh karena itu, sejarah awal video game mencakup periode waktu antara game elektronik interaktif pertama dengan layar elektronik pada tahun 1947, video game pertama yang sebenarnya pada awal tahun 1950an, dan kebangkitan video game arcade awal pada tahun 1970an ( Pong dan permulaan generasi pertama konsol video game dengan Magnavox Odyssey , keduanya pada tahun 1972). Selama masa ini terdapat berbagai macam perangkat dan penemuan yang sejalan dengan kemajuan besar dalam teknologi komputasi, dan video game pertama sebenarnya bergantung pada definisi "video game" yang digunakan.</p>
        <p>Menyusul penemuan perangkat hiburan tabung sinar katoda pada tahun 1947 —permainan elektronik interaktif paling awal yang diketahui serta yang pertama menggunakan layar elektronik—video game pertama yang sebenarnya diciptakan pada awal tahun 1950-an. Awalnya diciptakan sebagai demonstrasi teknologi, seperti komputer Bertie the Brain dan Nimrod pada tahun 1950 dan 1951, video game juga menjadi bidang penelitian akademis. Serangkaian permainan, umumnya simulasi permainan papan dunia nyata, diciptakan di berbagai lembaga penelitian untuk mengeksplorasi pemrograman, interaksi manusia-komputer , dan algoritma komputer. Ini termasuk rancangan program OXO dan Christopher Strachey pada tahun 1952, permainan berbasis perangkat lunak pertama yang menggunakan tampilan CRT, dan beberapa program catur dan catur. Mungkin video game pertama yang dibuat hanya untuk hiburan adalah Tennis for Two tahun 1958 , yang menampilkan grafik bergerak pada osiloskop . Seiring dengan kemajuan teknologi komputasi dari waktu ke waktu, komputer menjadi lebih kecil dan lebih cepat, dan kemampuan untuk mengerjakannya terbuka bagi pegawai universitas dan mahasiswa sarjana pada akhir tahun 1950-an. Pemrogram baru ini mulai membuat game untuk tujuan non-akademik, menjelang rilis Spacewar! sebagai salah satu permainan komputer digital paling awal yang diketahui tersedia di luar satu lembaga penelitian.</p>
        <p>Sepanjang sisa tahun 1960-an semakin banyak pemrogram yang menulis permainan komputer digital, yang terkadang dijual secara komersial dalam bentuk katalog. Ketika audiens video game meluas ke lebih dari beberapa lusin lembaga penelitian dengan turunnya harga komputer, dan bahasa pemrograman yang dapat dijalankan di berbagai jenis komputer diciptakan, variasi permainan yang lebih luas mulai dikembangkan. Video game bertransisi ke era baru di awal tahun 1970-an dengan diluncurkannya industri video game komersial pada tahun 1971 dengan ditampilkannya game arcade yang dioperasikan dengan koin Galaxy Game dan dirilisnya video game arcade pertama Computer Space , dan kemudian pada tahun 1972 dengan dirilisnya game arcade Pong yang sangat sukses dan konsol video game rumahan pertama , Magnavox Odyssey, yang meluncurkan konsol video game generasi pertama.</p>
    </div>
</body>
</html>
