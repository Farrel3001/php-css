<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Beranda</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="navbar">
        <a href="index.php">Beranda</a>
        <a href="articles.php">Artikel</a>
        <a href="profile.php">Profil</a>
    </div>
    <div class="content">
        <h1>Selamat Datang Di Website saya</h1>
        <p>Terimakasih untuk Pak Buyung yang sudah melihat tugas saya</p>
    </div>
</body>
</html>
